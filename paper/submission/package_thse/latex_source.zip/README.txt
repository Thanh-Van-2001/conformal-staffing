Anonymous manuscript for double-anonymous review.
Main file: manuscript_anonymous.tex. Compile with pdflatex (run bibtex once with thseapa.bst if the
bibliography is to be regenerated; manuscript_anonymous.bbl is included). All files are in one flat
directory: figures are vector PDFs, numbers are in macros.tex and thse_counts.tex.
